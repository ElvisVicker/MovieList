import { useEffect, useState } from "react"
import { Link, Routes, Route } from "react-router-dom"

export default function TopRated() {

    return (
        <div className="">

   
TopRated
        </div >
    )
}